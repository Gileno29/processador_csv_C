#include <stdio.h>
#include "libcsv.h"


int main() {
    //const char csv[] = "header1,header2,header3,header4\n1,2,3,4\n5,6,7,8\n9,10,11,12";
    //processCsv(csv, "header1,header3,header4", "header1>1\nheader3<10");

    const char csvFilePath[] = "./data.csv";
    processCsvFile(csvFilePath, "header1,header3,header4", "header1>1\nheader3<10");

    return 0;
}
