#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libcsv.h"
#define MAX_COLUMNS 256
#define MAX_LINE_LENGTH 1024

typedef struct {
    char *header;
    int columnIndex;
    char comparator;
    char *value;
} Filter;

void parseFilters(const char *rowFilterDefinitions, Filter *filters, int *filterCount);
int parseSelectedColumns(const char *selectedColumns, char **columns);
void filterAndPrintCsv(char *csv, char **selectedColumns, int selectedColumnCount, Filter *filters, int filterCount);
int applyFilter(char **row, Filter *filters, int filterCount, char **headers);
int compare(const char *a, const char *b, char comparator);

void processCsv(const char csv[], const char selectedColumns[], const char rowFilterDefinitions[]) {
    char *csvCopy = strdup(csv);
    Filter filters[MAX_COLUMNS];
    int filterCount = 0;
    parseFilters(rowFilterDefinitions, filters, &filterCount);

    char *selectedColumnsArray[MAX_COLUMNS];
    int selectedColumnCount = parseSelectedColumns(selectedColumns, selectedColumnsArray);
    printf("Estrou na process csv atraves da funcao de leitura");
    filterAndPrintCsv(csvCopy, selectedColumnsArray, selectedColumnCount, filters, filterCount);

    free(csvCopy);
}

void parseFilters(const char *rowFilterDefinitions, Filter *filters, int *filterCount) {
     char *definitions = strdup(rowFilterDefinitions);
    if (definitions == NULL) {
        fprintf(stderr, "Memory allocation error\n");
        return;
    }

    char *line = strtok(definitions, "\n");
    while (line != NULL) {
        //printf("Processando linha: %s\n", line);
        char *header = line;
        char *compPos = strpbrk(line, "><="); // Encontra a posição do primeiro comparador
        
        if (compPos == NULL) {
            fprintf(stderr, "Error parsing comparator\n");
            break;
        }

        char comparator = *compPos; // O comparador é o caractere na posição encontrada
        *compPos = '\0'; // Termina o header aqui
        char *value = compPos + 1; // O valor começa após o comparador

        filters[*filterCount].header = strdup(header);
        filters[*filterCount].comparator = comparator;
        filters[*filterCount].value = strdup(value);

        if (filters[*filterCount].header == NULL || filters[*filterCount].value == NULL) {
            fprintf(stderr, "Memory allocation error\n");
            break;
        }

        (*filterCount)++;
        line = strtok(NULL, "\n");
    }

    free(definitions);
}

int parseSelectedColumns(const char *selectedColumns, char **columns) {
    int count = 0;
    char *columnsCopy = strdup(selectedColumns);
    char *column = strtok(columnsCopy, ",");
    while (column != NULL) {
        columns[count++] = strdup(column);
        column = strtok(NULL, ",");
    }
    free(columnsCopy);
    return count;
}


/*  filtra e  printa no stdout */
void filterAndPrintCsv(char *csv, char **selectedColumns, int selectedColumnCount, Filter *filters, int filterCount) {
   char *lines[MAX_LINE_LENGTH];
    int lineCount = 0;
    int countlines=0;
    // Tokenizar as linhas do CSV
    char *line = strtok(csv, "\n");
    while (line != NULL) {
        if (lineCount >= MAX_LINE_LENGTH) {
            fprintf(stderr, "Error: too many lines in CSV\n");
            return;
        }
        lines[lineCount++] = line;
        countlines++;
        line = strtok(NULL, "\n");
    }

    // Tokenizar os cabeçalhos
    char *headers[MAX_COLUMNS];
    int columnCount = 0;
    line = lines[0];
    char *header = strtok(line, ",");
    while (header != NULL) {
        if (columnCount >= MAX_COLUMNS) {
            fprintf(stderr, "Error: too many columns in CSV\n");
            return;
        }
        headers[columnCount++] = header;
        header = strtok(NULL, ",");
    }

    // Inicializar selectedIndices
    int selectedIndices[MAX_COLUMNS];
    for (int i = 0; i < MAX_COLUMNS; i++) {
        selectedIndices[i] = -1;
    }

    // Encontrar os índices das colunas selecionadas
    for (int i = 0; i < selectedColumnCount; i++) {
        for (int j = 0; j < columnCount; j++) {
            if (strcmp(selectedColumns[i], headers[j]) == 0) {
                selectedIndices[i] = j;
                break;
            }
        }
    }

    
    // Imprimir cabeçalhos das colunas selecionadas
    for (int i = 0; i < selectedColumnCount; i++) {
        if (selectedIndices[i] < 0 || selectedIndices[i] >= columnCount) {
            //fprintf(stderr, "Error: selected index %d out of bounds\n", selectedIndices[i]);
            continue;
        }

        if (headers[selectedIndices[i]] == NULL) {
            //fprintf(stderr, "Error: header at index %d is NULL\n", selectedIndices[i]);
            continue;
        }

        printf("%s", headers[selectedIndices[i]]);
        if (i < selectedColumnCount - 1) {
            printf(",");
        }
    }
    printf("\n");

    // Processar e imprimir as linhas filtradas
    for (int i = 1; i < lineCount; i++) {
       // printf("estou aqui 02");
        
        char *row[MAX_COLUMNS];
        int colIndex = 0;
        char *token = strtok(lines[i], ",");
        while (token != NULL) {
            if (colIndex >= MAX_COLUMNS) {
                fprintf(stderr, "Error: too many columns in line %d\n", i);
                break;
            }
            row[colIndex++] = token;
            token = strtok(NULL, ",");
        }

       
        if (applyFilter(row, filters, filterCount, headers)) {
            //printf("estou aqui");
            for (int j = 0; j < selectedColumnCount; j++) {
                if (selectedIndices[j] < 0 || selectedIndices[j] >= colIndex) {
                    fprintf(stderr, "Error: selected column index %d out of bounds in line %d\n", selectedIndices[j], i);
                    continue;
                }
                printf("%s", row[selectedIndices[j]]);
                if (j < selectedColumnCount - 1) {
                    printf(",");
                }
            }
            printf("\n"); 
            break; //REVISAR (GAMBIARRA)
        }
    }
}

int applyFilter(char **row, Filter *filters, int filterCount, char **headers) {
    //printf("esse é meu filter count %d", filterCount);
    for (int i = 0; i < filterCount; i++) {
        int columnIndex = -1;
        // Adicionar verificação de segurança para headers
        for (int j = 0; j < MAX_COLUMNS; j++) {
            if (headers[j] && strcmp(headers[j], filters[i].header) == 0) {
                //printf("erroo");
                columnIndex = j;
                break;
            }
        }

        if (columnIndex == -1 || columnIndex >= MAX_COLUMNS || row[columnIndex] == NULL) {
            fprintf(stderr, "Error: invalid column index %d or NULL value in row\n", columnIndex);
            return 0;
        }

        // Verificar se a comparação é bem-sucedida
        if (!compare(row[columnIndex], filters[i].value, filters[i].comparator)) {
            return 0;
        }else{
            return 1;
            
        }
    }
    return 1;
}

int compare(const char *a, const char *b, char comparator) {

   if (a == NULL || b == NULL) {
        fprintf(stderr, "Error: one of the strings is NULL in compare function.\n");
        return 0;
    }


    if (comparator != '>' && comparator != '<' && comparator != '=') {
        fprintf(stderr, "Error: invalid comparator '%c' in compare function.\n", comparator);
        return 0;
    }

    int cmp = strcmp(a, b);
    //printf("Comparing '%s' with '%s' using comparator '%c': cmp = %d\n", a, b, comparator, cmp);

    switch (comparator) {
        case '>': return cmp > 0;
        case '<': return cmp < 0;
        case '=': return cmp == 0;
        default:
            fprintf(stderr, "Error: invalid comparator '%c' in compare function.\n", comparator);
            return 0;
    }
}

void processCsvFile(const char csvFilePath[], const char selectedColumns[], const char rowFilterDefinitions[]) {
    FILE *file = fopen(csvFilePath, "r");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    

    char *csvData = (char *)malloc(fileSize + 1);
    fread(csvData, 1, fileSize, file);
    csvData[fileSize] = '\0';
    printf("estou na funcao de leitura de csv");
    fclose(file);
    
    printf("Conteúdo de csvData:\n%s\n", csvData);

    processCsv(csvData, selectedColumns, rowFilterDefinitions);
    printf("estou na funcao de leitura de csv 02");

   free(csvData);
}

